export const res = {
  resLength: '5',
  resList: [
    {id: 1, name: 'US Dolar'},
    {id: 2, name: 'Puyolets'},
    {id: 3, name: 'Euro'},
    {id: 4, name: 'BAT'},
    {id: 5, name: 'Libra'}
  ]
}